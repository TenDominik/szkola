const express = require('express');
const app = express();
app.use(express.static('public'));
app.route('/nigger').get(function(req,res){
    res.send('tajny niger skrypt');
});
app.get('/', (req,res) => {
    console.log(`Załadowano plik ${html}`);
    console.log(`Użycie .protocol(): ${req.protocol}`);
    console.log(`Użycie .secure(): ${req.secure}`);

});
app.listen(3000, function(){
    console.log('Serwer startuje na porcie 3000');
});